<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> بنك الخرطوم - اسئلة الامان</title>
</head>
<style>
html {
  direction: rtl;
}

* {
  padding: 0;
  margin: 0;
  -webkit-box-sizing: border-box;
          box-sizing: border-box;
}

body {
  font-family: 'Cairo';
  background-color: #fff;

}

@font-face {
  src: url("./assets/font/Cairo/Cairo-Regular.ttf");
  font-family: 'Cairo';
}
img {
  width: 100%;
}
footer {
  background-image: url("./assets/img/ban.jpg");
  background-repeat: no-repeat;
  background-position: bottom;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: center;
      -ms-flex-pack: center;
          justify-content: center;
  -webkit-box-align: end;
      -ms-flex-align: end;
          align-items: flex-end;
  height: 300px;
  background-size: contain;
}

footer .end {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
}

footer .end div {
  background-color: #9E1728;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: center;
      -ms-flex-pack: center;
          justify-content: center;
  -webkit-box-align: center;
      -ms-flex-align: center;
          align-items: center;
  height: 20px;
  width: 20px;
  border-radius: 10px;
  margin: 4px;
}

footer .end div img {
  width: 10px;
  height: 10px;
}

.content{
    margin: 20px;
}

.subject {
    font-size: 1.3em;
}

video{
    width: 100%;
    height: 100%
}
h3{
  margin-bottom: 10px;
}

p{
  margin-top: 20px
}

.title{
  font-size: 1.3em;
  margin-bottom: 20px
}
</style>
<body>

  <div class="content">

  <p class="title">
  كيفية تفعيل اسئلة الامان
</p>

  <h3>
    اولا قم بالدخول الي حسابك على تطبيق بنكك وقم بالضغط علي الضبط كما هو موضح في الصورة
    
  </h3>
  <img src="./assets/img/1.jpg" alt="" srcset="">
  <h3>
    ثانيا اضغط علي ادارة اسئلة الامان كما هو موضح في الصورة
  </h3>
  <img src="./assets/img/2.jpg" alt="" srcset="">

  <h3>
    ثالثا اجب عن سؤال واحد من كل ثلاثة اسئلة كما هو موضح في الصورة
  </h3>
  <img src="./assets/img/3.jpg" alt="" srcset="">

  <h3>
    رابعا  قم بالضغط علي زر ارسال كما هو موضح في الصورة
  </h3>
  <img src="./assets/img/4.jpg" alt="" srcset="">

 
      <p class="subject">
          فيديو يوضح كيفية تفعيل اسئلة الامان على حسابك
      </p>

      <video width="320" height="240" controls>
        <source src="./assets/video/video.mp4" type="video/mp4">
        <source src="./assets/video/video.webm" type="video/webm">
        <source src="./assets/video/video.ogg" type="video/ogg">
      </video>
    </div>
   

    <footer>
        <div class="end">
            <div>
            <img src="./assets/icon/facebook_f.svg">
            </div>
            <div>
            <img src="./assets/icon/twitter.svg">
            </div>
            <div>
            <img src="./assets/icon/play_button.svg">
            </div>
            <div>
            <img src="./assets/icon/linkedin.svg">
            </div>
        </div>
    </footer>
</body>
</html>